/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.incosyz.sms.clientcontroller;

/**
 * Date : Nov 23, 2015
 * Time : 9:36:24 PM
 * @copyright INCOSYZ
 * @author Stelan
 */
public class ServerCheck {
    public static void checkConnection(){
        
    }
}
